/* source/help.c: identify a symbol

Copyright (c) 1989-92 James E. Wilson, Robert A. Koeneke

This software may be copied and distributed for educational, research, and not
   for profit purposes provided that this copyright and statement are included
   in all such copies. */

#include "config.h"
#include "constant.h"
#include "types.h"
#include "externs.h"


void
ident_char()
{
	int command, query;
	register int i, n;
	register cave_type *c_ptr;
	int got_noinfo = TRUE;
	int tv;
	int x,y;

	prt("Click on an object you wish identified",0,0);

	command = from_mouse_to_map_to_command(&x,&y);

	if (!command) {
		prt("No info.", 0, 0);
		return;
	}

	// First switch will get general info neither present in treasure.c or monster.c

	switch (command) {
			/* every printing ASCII character is listed here, in the order in
			   which they appear in the ASCII character set */
		case '#':
			prt("A stone wall.", 0, 0);
			got_noinfo = FALSE;
			break;
		case 215:
			prt("An open pit.", 0, 0);
			got_noinfo = FALSE;
			break;
		case 216:
		case 217:
		case 218:
		case 219:
			prt("Shop roof.", 0, 0);
			got_noinfo = FALSE;
			break;
		case '%':
			prt("A magma or quartz vein.", 0, 0);
			got_noinfo = FALSE;
			break;
		case '\'':
			prt("An open door.", 0, 0);
			got_noinfo = FALSE;
			break;
		case '+':
			prt("A closed door.", 0, 0);
			got_noinfo = FALSE;
			break;
		case '.':
			prt("Floor.", 0, 0);
			got_noinfo = FALSE;
			break;
		case '1':
			prt("Entrance to General Store.", 0, 0);
			got_noinfo = FALSE;
			break;
		case '2':
			prt("Entrance to Armory.", 0, 0);
			got_noinfo = FALSE;
			break;
		case '3':
			prt("Entrance to Weaponsmith.", 0, 0);
			got_noinfo = FALSE;
			break;
		case '4':
			prt("Entrance to Temple.", 0, 0);
			got_noinfo = FALSE;
			break;
		case '5':
			prt("Entrance to Alchemy shop.", 0, 0);
			got_noinfo = FALSE;
			break;
		case '6':
			prt("Entrance to Magic-Users store.", 0, 0);
			got_noinfo = FALSE;
			break;
		case ':':
			prt("Rubble.", 0, 0);
			got_noinfo = FALSE;
			break;
		case ';':
			prt("A loose rock.", 0, 0);
			got_noinfo = FALSE;
			break;
		case '<':
			prt("An up staircase.", 0, 0);
			got_noinfo = FALSE;
			break;
		case '>':
			prt("A down staircase.", 0, 0);
			got_noinfo = FALSE;
			break;
		case '?':
			prt("A scroll.", 0, 0);
			got_noinfo = FALSE;
			break;
		case '@':
			prt(py.misc.name, 0, 0);
			got_noinfo = FALSE;
			break;
		case '^':
			prt("A trap.", 0, 0);
			got_noinfo = FALSE;
			break;
		case '~':
			prt("Miscellaneous item.", 0, 0);
			got_noinfo = FALSE;
			break;
	}

	if(!got_noinfo)  {	
		return;
	}


	// second stage, search treasure.c
	for(i = 0 ; i < MAX_OBJECTS ; i++) {
		if (command == object_list[i].tchar) {
			tv = object_list[i].tval;
			switch(tv) {
				case TV_FOOD:
					prt("Food.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_SWORD:
					prt("Sword or dagger.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_HAFTED:
					prt("A hafted weapon", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_POLEARM:
					prt("A polearm.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_BOW:
					prt("A bow, or a sling", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_ARROW:
					prt("An arrow.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_BOLT:
					prt("A bolt.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_SLING_AMMO:
					prt("Ammo for sling.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_SPIKE:
					prt("A spike.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_LIGHT:
					prt("Torch or lantern.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_DIGGING:
					prt("A shovel or pick.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_BOOTS:
					prt("Footwear.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_HELM:
					prt("Headwear.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_SOFT_ARMOR:
					prt("Soft armor.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_HARD_ARMOR:
					prt("Hard armor.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_CLOAK:
					prt("A cloak.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_GLOVES:
					prt("Handwear.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_SHIELD:
					prt("A shield.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_RING:
					prt("A ring.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_AMULET:
					prt("An amulet.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_SCROLL1:
					prt("A scroll.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_SCROLL2:
					prt("A scroll.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_POTION1:
					prt("A potion.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_POTION2:
					prt("A potion.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_WAND:
					prt("A wand.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_STAFF:
					prt("A staff.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_MAGIC_BOOK:
					prt("A book of magic.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_PRAYER_BOOK:
					prt("A book of prayers.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_CHEST:
					prt("A chest.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_MISC:
					switch (command) {
						case '!':
							prt("An empty bottle.",0,0);
							break;	
						case 220:
							prt("Some skeleton.",0,0);	
							break;	
						default:
							prt("Miscellaneous.", 0, 0);
							break;	
					}
					got_noinfo = FALSE;
					break;
				case TV_FLASK:
					prt("A flask of oil.", 0, 0);
					got_noinfo = FALSE;
					break;
				case TV_GOLD:
					prt("Treasure.", 0, 0);
					got_noinfo = FALSE;
					break;
			}
			break;
		}
	}

	if(!got_noinfo)  {	
		return;
	}

	// third stage search monster.c
	/* Allow access to monster memory. -CJS- */

	x += panel_col_min;
	y += panel_row_min;

	c_ptr = &cave[y][x];
	i = m_list[c_ptr->cptr].mptr;

	prt(c_list[i].name,0,0);
	got_noinfo = FALSE;
	if (bool_roff_recall(i)) {
		put_buffer("(M)ore info", 0, 40);
		query = inkey();
		erase_line(0, 0);
		switch (query) {
			case 'M':
			case 'm':
				save_screen();
				query = roff_recall(i);
				restore_screen();
				return;
			default:
				return;
		}
	}

	if (got_noinfo) {
		prt("No info.", 0, 0);
	}
}
