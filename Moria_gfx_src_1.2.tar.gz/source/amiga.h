// Include file for amiga gfx package into umoria 5.4
// Only needed in io.c
  
#ifndef CURSES_H
#define CURSES_H

#ifndef stdin    /* May be a better way to do this !! */
#include <stdio.h>
#endif /* stdin */

#ifndef TRUE
#define TRUE      1 
#define FALSE     0 
#endif /* TRUE */

#define ERR      -1
#define OK        0

extern int LINES, COLS;

#endif
