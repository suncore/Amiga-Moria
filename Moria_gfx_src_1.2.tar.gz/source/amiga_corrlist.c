
extern int GFX_CORR[2][256];


init_GFX_CORR() {
	int x=0;
	int y=1;
	int i,j;
	int cx,cy;

	for(i =0; i<= 255; i++) {
		cx = randint(33)-1; // hack to get hallucinate to always display graphics
		cy = randint(7)-1;
		if ((cx<20) && (cx>13)) cx -= 6;
		GFX_CORR[y][i] = cy;
		GFX_CORR[x][i] = cx;
	}

	GFX_CORR[y]['p'] =  0;
	GFX_CORR[x]['p'] =  10;

	GFX_CORR[y][','] = 2; 
	GFX_CORR[x][','] = 16;

	GFX_CORR[y]['c'] = 2; 
	GFX_CORR[x]['c'] =  7;

	GFX_CORR[y]['i'] =  0 ; 
	GFX_CORR[x]['i'] = 8  ; 

	GFX_CORR[y]['r'] =  4 ; 
	GFX_CORR[x]['r'] =  10 ; 

	GFX_CORR[y]['R'] =  1 ; 
	GFX_CORR[x]['R'] =  5 ; 

	GFX_CORR[y]['k'] = 2  ; 
	GFX_CORR[x]['k'] = 8  ; 

	GFX_CORR[y]['w'] =  1 ; 
	GFX_CORR[x]['w'] =  11 ; 

	GFX_CORR[y]['e'] =  5 ; 
	GFX_CORR[x]['e'] =  7 ; 

	GFX_CORR[y]['J'] =  0 ; 
	GFX_CORR[x]['J'] =  4 ; 

	GFX_CORR[y]['f'] =  3 ; 
	GFX_CORR[x]['f'] =  6 ; 

	GFX_CORR[y]['a'] = 2  ; 
	GFX_CORR[x]['a'] = 6  ; 

	GFX_CORR[y]['h'] = 5  ; 
	GFX_CORR[x]['h'] = 6  ; 

	GFX_CORR[y]['y'] = 2  ; 
	GFX_CORR[x]['y'] = 20  ; 

	GFX_CORR[y]['.'] = 1  ; 
	GFX_CORR[x]['.'] = 20  ; 

	GFX_CORR[y]['@'] = 2  ; 
	GFX_CORR[x]['@'] = 10  ; 

	GFX_CORR[y]['#'] = 2  ; 
	GFX_CORR[x]['#'] = 13  ; 

	GFX_CORR[y]['G'] =  3 ; 
	GFX_CORR[x]['G'] = 3  ; 

	GFX_CORR[y]['l'] = 3  ; 
	GFX_CORR[x]['l'] = 8  ; 

	GFX_CORR[y]['n'] = 5  ; 
	GFX_CORR[x]['n'] = 8  ; 

	GFX_CORR[y]['b'] = 1  ; 
	GFX_CORR[x]['b'] = 7  ; 

	GFX_CORR[y]['m'] =  2 ; 
	GFX_CORR[x]['m'] =  19 ; 

	GFX_CORR[y]['$'] =  0 ; 
	GFX_CORR[x]['$'] =  13 ; 

	GFX_CORR[y]['j'] = 1  ; 
	GFX_CORR[x]['j'] = 8  ; 

	GFX_CORR[y]['s'] =  5 ; 
	GFX_CORR[x]['s'] =  10 ; 

	GFX_CORR[y]['F'] = 2  ; 
	GFX_CORR[x]['F'] = 3  ; 

	GFX_CORR[y]['z'] =  2 ; 
	GFX_CORR[x]['z'] =  11 ; 

	GFX_CORR[y]['Y'] =  3 ; 
	GFX_CORR[x]['Y'] =  11 ; 

	GFX_CORR[y]['o'] =  0 ; 
	GFX_CORR[x]['o'] =  9 ; 

	GFX_CORR[y]['t'] = 3  ; 
	GFX_CORR[x]['t'] = 20  ; 

	GFX_CORR[y]['H'] = 4  ; 
	GFX_CORR[x]['H'] = 3  ; 

	GFX_CORR[y]['E'] = 4  ; 
	GFX_CORR[x]['E'] = 2  ; 

	GFX_CORR[y]['K'] = 1  ; 
	GFX_CORR[x]['K'] = 4  ; 

	GFX_CORR[y]['P'] = 5  ; 
	GFX_CORR[x]['P'] = 4  ; 

	GFX_CORR[y]['g'] = 4  ; 
	GFX_CORR[x]['g'] = 6  ; 

	GFX_CORR[y]['U'] = 4  ; 
	GFX_CORR[x]['U'] = 5  ; 

	GFX_CORR[y]['C'] = 2  ; 
	GFX_CORR[x]['C'] = 2  ; 

	GFX_CORR[y]['q'] = 3  ; 
	GFX_CORR[x]['q'] = 10  ; 

	GFX_CORR[y]['T'] = 3  ; 
	GFX_CORR[x]['T'] = 5  ; 

	GFX_CORR[y]['S'] = 2  ; 
	GFX_CORR[x]['S'] = 5  ; 

	GFX_CORR[y]['O'] = 4  ; 
	GFX_CORR[x]['O'] = 4  ; 

	GFX_CORR[y]['M'] = 3  ; 
	GFX_CORR[x]['M'] = 4  ; 

	GFX_CORR[y]['Q'] = 0  ; 
	GFX_CORR[x]['Q'] =  5 ; 

	GFX_CORR[y]['W'] =  0 ; 
	GFX_CORR[x]['W'] =  6 ; 

	GFX_CORR[y]['V'] = 5  ; 
	GFX_CORR[x]['V'] = 5  ; 

	GFX_CORR[y]['d'] = 3  ; 
	GFX_CORR[x]['d'] = 7  ; 

	GFX_CORR[y]['A'] = 0  ; 
	GFX_CORR[x]['A'] = 2  ; 

	GFX_CORR[y]['L'] = 2  ; 
	GFX_CORR[x]['L'] = 4  ; 

	GFX_CORR[y]['X'] = 1  ; 
	GFX_CORR[x]['X'] = 6  ; 

	GFX_CORR[y]['D'] = 3  ; 
	GFX_CORR[x]['D'] = 2  ; 

	GFX_CORR[y]['B'] = 1  ; 
	GFX_CORR[x]['B'] = 2  ; 

	GFX_CORR[y][' '] = 1  ; 
	GFX_CORR[x][' '] = 21  ; 

	GFX_CORR[y]['!'] = 4  ; 
	GFX_CORR[x]['!'] = 12  ; 

	GFX_CORR[y]['*'] = 1  ; 
	GFX_CORR[x]['*'] = 13  ; 

	GFX_CORR[y]['&'] = 4  ; 
	GFX_CORR[x]['&'] = 13  ; 

	GFX_CORR[y]['\''] =  0 ; 
	GFX_CORR[x]['\''] =  14 ; 

	GFX_CORR[y]['+'] =  2 ; 
	GFX_CORR[x]['+'] =  14 ; 

	GFX_CORR[y]['('] = 4  ; 
	GFX_CORR[x]['('] = 20  ; 

	GFX_CORR[y]['['] = 6  ; 
	GFX_CORR[x]['['] = 20  ; 

	GFX_CORR[y][']'] = 1  ; 
	GFX_CORR[x][']'] = 12  ; 

	GFX_CORR[y][')'] = 5  ; 
	GFX_CORR[x][')'] = 19  ; 



	GFX_CORR[y]['-'] = 0  ; 
	GFX_CORR[x]['-'] = 1  ; 

	GFX_CORR[y]['='] = 1  ; 
	GFX_CORR[x]['='] = 1  ; 

	GFX_CORR[y]['?'] = 2  ; 
	GFX_CORR[x]['?'] = 1  ; 

	GFX_CORR[y]['_'] = 3  ; 
	GFX_CORR[x]['_'] = 1  ; 

	GFX_CORR[y]['}'] = 4  ; 
	GFX_CORR[x]['}'] = 16  ; 

	GFX_CORR[y]['{'] = 5  ; 
	GFX_CORR[x]['{'] = 15  ; 

	GFX_CORR[y]['/'] = 6  ; 
	GFX_CORR[x]['/'] = 8  ; 

	GFX_CORR[y]['|'] = 6  ; 
	GFX_CORR[x]['|'] = 6  ; 

	GFX_CORR[y]['\\'] = 6  ; 
	GFX_CORR[x]['\\'] = 10  ; 

	GFX_CORR[y]['"'] = 5  ; 
	GFX_CORR[x]['"'] = 12  ; 

	GFX_CORR[y]['~'] = 1  ; 
	GFX_CORR[x]['~'] = 0  ; 

	GFX_CORR[y][':'] = 4  ; 
	GFX_CORR[x][':'] =  1 ; 

	GFX_CORR[y]['^'] = 5  ; 
	GFX_CORR[x]['^'] = 1  ; 

	GFX_CORR[y]['<'] = 6  ; 
	GFX_CORR[x]['<'] = 0  ; 

	GFX_CORR[y]['>'] = 3  ; 
	GFX_CORR[x]['>'] = 18  ; 

	GFX_CORR[y]['1'] = 1  ; 
	GFX_CORR[x]['1'] = 0  ; 

	GFX_CORR[y]['2'] = 0  ; 
	GFX_CORR[x]['2'] = 0  ; 

	GFX_CORR[y]['3'] = 5  ; 
	GFX_CORR[x]['3'] = 0  ; 

	GFX_CORR[y]['4'] = 2  ; 
	GFX_CORR[x]['4'] = 0  ; 

	GFX_CORR[y]['5'] = 3  ; 
	GFX_CORR[x]['5'] = 0  ; 

	GFX_CORR[y]['6'] = 4  ; 
	GFX_CORR[x]['6'] = 0  ;

	GFX_CORR[y]['%'] = 0  ; 
	GFX_CORR[x]['%'] = 20  ;

	GFX_CORR[y][128] = 0  ; 
	GFX_CORR[x][128] =  7 ;

	GFX_CORR[y][129] = 5  ; 
	GFX_CORR[x][129] =  2 ;

	GFX_CORR[y][130] = 0  ; 
	GFX_CORR[x][130] =  3 ;

	GFX_CORR[y][131] = 1  ; 
	GFX_CORR[x][131] = 3  ;

	GFX_CORR[y]['I'] = 5  ; 
	GFX_CORR[x]['I'] = 3  ;

	GFX_CORR[y][132] =  4 ; 
	GFX_CORR[x][132] = 7  ;

	GFX_CORR[y][133] = 4  ; 
	GFX_CORR[x][133] = 9  ;

	GFX_CORR[y][134] = 2  ; 
	GFX_CORR[x][134] =  21 ;

	GFX_CORR[y][135] = 1  ; 
	GFX_CORR[x][135] = 9  ;

	GFX_CORR[y][136] = 3  ; 
	GFX_CORR[x][136] = 21  ;

	GFX_CORR[y][137] = 4  ; 
	GFX_CORR[x][137] = 21  ;

	GFX_CORR[y][138] = 5  ; 
	GFX_CORR[x][138] = 9  ;

	GFX_CORR[y][139] = 5  ; 
	GFX_CORR[x][139] = 21  ;

	GFX_CORR[y][140] = 0  ; 
	GFX_CORR[x][140] = 10  ;

	GFX_CORR[y][141] = 6  ; 
	GFX_CORR[x][141] = 21  ;

	GFX_CORR[y][142] = 4  ; 
	GFX_CORR[x][142] = 21  ;

	GFX_CORR[y][143] = 0  ; 
	GFX_CORR[x][143] = 22 ;

	GFX_CORR[y][144] = 1 ; 
	GFX_CORR[x][144] =  22 ;

	GFX_CORR[y][145] = 2  ; 
	GFX_CORR[x][145] = 22  ;

	GFX_CORR[y][145] = 2  ; 
	GFX_CORR[x][145] = 22  ;

	GFX_CORR[y][146] = 3  ; 
	GFX_CORR[x][146] = 22  ;

	GFX_CORR[y][147] = 5  ; 
	GFX_CORR[x][147] = 22  ;

	GFX_CORR[y][148] = 4  ; 
	GFX_CORR[x][148] = 22  ;

	GFX_CORR[y][149] = 6  ; 
	GFX_CORR[x][149] = 22  ;

	GFX_CORR[y][150] = 0  ; 
	GFX_CORR[x][150] = 23  ;

	GFX_CORR[y][151] = 1  ; 
	GFX_CORR[x][151] =23   ;

	GFX_CORR[y][152] = 2  ; 
	GFX_CORR[x][152] = 23  ;

	GFX_CORR[y][153] = 3  ; 
	GFX_CORR[x][153] = 23  ;

	GFX_CORR[y][154] = 4  ; 
	GFX_CORR[x][154] = 23  ;

	GFX_CORR[y][155] = 1  ; 
	GFX_CORR[x][155] =  22 ;

	GFX_CORR[y][156] = 5  ; 
	GFX_CORR[x][156] = 23  ;

	GFX_CORR[y][157] = 2  ; 
	GFX_CORR[x][157] = 12  ;

	GFX_CORR[y][158] = 3  ; 
	GFX_CORR[x][158] = 12  ;

	GFX_CORR[y][159] = 4  ; 
	GFX_CORR[x][159] = 11  ;

	GFX_CORR[y][160] = 5  ; 
	GFX_CORR[x][160] = 11  ;

	GFX_CORR[y][161] = 0  ; 
	GFX_CORR[x][161] = 24  ;

	GFX_CORR[y][162] = 0  ; 
	GFX_CORR[x][162] = 12  ;

	GFX_CORR[y][163] = 1  ; 
	GFX_CORR[x][163] = 12  ;

	GFX_CORR[y][164] = 3  ; 
	GFX_CORR[x][164] = 13  ;

	GFX_CORR[y][165] = 4  ; 
	GFX_CORR[x][165] = 13  ;

	GFX_CORR[y][166] = 5  ; 
	GFX_CORR[x][166] = 13  ;

	GFX_CORR[y][167] = 1  ; 
	GFX_CORR[x][167] = 24  ;

	GFX_CORR[y][168] = 2  ; 
	GFX_CORR[x][168] = 24  ;

	GFX_CORR[y][169] = 4  ; 
	GFX_CORR[x][169] = 20  ;

	GFX_CORR[y][170] = 6  ; 
	GFX_CORR[x][170] = 20  ;

	GFX_CORR[y][171] = 0  ; 
	GFX_CORR[x][171] = 21  ;

	GFX_CORR[y][172] = 1  ; 
	GFX_CORR[x][172] = 16  ;

	GFX_CORR[y][173] = 1  ; 
	GFX_CORR[x][173] = 17  ;

	GFX_CORR[y][174] = 1  ; 
	GFX_CORR[x][174] = 18  ;

	GFX_CORR[y][175] = 1  ; 
	GFX_CORR[x][175] = 19  ;

	GFX_CORR[y][176] = 5  ; 
	GFX_CORR[x][176] = 18  ;

	GFX_CORR[y][177] = 5  ; 
	GFX_CORR[x][177] = 19  ;

	GFX_CORR[y][178] = 5  ; 
	GFX_CORR[x][178] = 20  ;

	GFX_CORR[y][179] = 2  ; 
	GFX_CORR[x][179] = 16  ;

	GFX_CORR[y][180] = 2  ; 
	GFX_CORR[x][180] = 17  ;

	GFX_CORR[y][181] = 2  ; 
	GFX_CORR[x][181] = 18  ;

	GFX_CORR[y][182] = 2  ; 
	GFX_CORR[x][182] = 19  ;

	GFX_CORR[y][183] = 3  ; 
	GFX_CORR[x][183] = 24  ;

	GFX_CORR[y][184] = 4  ; 
	GFX_CORR[x][184] = 15  ;

	GFX_CORR[y][185] = 4  ; 
	GFX_CORR[x][185] = 16  ;

	GFX_CORR[y][186] = 4  ; 
	GFX_CORR[x][186] = 17  ;

	GFX_CORR[y][187] = 4  ; 
	GFX_CORR[x][187] = 18  ;

	GFX_CORR[y][188] = 4  ; 
	GFX_CORR[x][188] = 24  ;

	GFX_CORR[y][189] = 5  ; 
	GFX_CORR[x][189] = 15  ;

	GFX_CORR[y][190] = 5  ; 
	GFX_CORR[x][190] = 16  ;

	GFX_CORR[y][191] = 5  ; 
	GFX_CORR[x][191] = 17  ;

	GFX_CORR[y][192] = 6  ; 
	GFX_CORR[x][192] = 1  ;

	GFX_CORR[y][193] = 6  ; 
	GFX_CORR[x][193] = 2  ;

	GFX_CORR[y][194] = 6  ; 
	GFX_CORR[x][194] = 3  ;

	GFX_CORR[y][195] = 6  ; 
	GFX_CORR[x][195] = 4  ;

	GFX_CORR[y][196] = 6  ; 
	GFX_CORR[x][196] = 5  ;

	GFX_CORR[y][197] = 6  ; 
	GFX_CORR[x][197] = 6  ;

	GFX_CORR[y][198] = 6  ; 
	GFX_CORR[x][198] = 7  ;

	GFX_CORR[y][199] = 6  ; 
	GFX_CORR[x][199] = 8  ;

	GFX_CORR[y][200] = 6  ; 
	GFX_CORR[x][200] = 9  ;

	GFX_CORR[y][201] = 6  ; 
	GFX_CORR[x][201] = 24  ;

	GFX_CORR[y][202] = 6  ; 
	GFX_CORR[x][202] = 11  ;

	GFX_CORR[y][203] = 6  ; 
	GFX_CORR[x][203] = 12  ;

	GFX_CORR[y][204] = 5  ; 
	GFX_CORR[x][204] = 24  ;

	GFX_CORR[y][205] = 6  ; 
	GFX_CORR[x][205] = 10  ;

	GFX_CORR[y][206] = 6  ; 
	GFX_CORR[x][206] = 13  ;

	GFX_CORR[y][207] = 6  ; 
	GFX_CORR[x][207] = 15  ;

	GFX_CORR[y][208] = 6  ; 
	GFX_CORR[x][208] = 17  ;

	GFX_CORR[y][209] = 6  ; 
	GFX_CORR[x][209] = 14  ;

	GFX_CORR[y][210] = 6  ; 
	GFX_CORR[x][210] = 16  ;

	GFX_CORR[y][211] = 3  ; 
	GFX_CORR[x][211] = 17  ;

	GFX_CORR[y][212] = 0  ; 
	GFX_CORR[x][212] = 25  ;

	GFX_CORR[y][213] = 1  ; 
	GFX_CORR[x][213] = 25  ;

	GFX_CORR[y][214] = 2  ; 
	GFX_CORR[x][214] = 25  ;

	GFX_CORR[y][215] = 3  ; 
	GFX_CORR[x][215] = 25  ;

	GFX_CORR[y][216] = 6  ; 
	GFX_CORR[x][216] = 25  ;

	GFX_CORR[y][217] = 0  ; 
	GFX_CORR[x][217] = 26  ;

	GFX_CORR[y][218] = 1  ; 
	GFX_CORR[x][218] = 26  ;

	GFX_CORR[y][219] = 2  ; 
	GFX_CORR[x][219] = 26  ;

	GFX_CORR[y][';'] = 3  ; 
	GFX_CORR[x][';'] = 26  ;

	GFX_CORR[y][220] = 5  ; 
	GFX_CORR[x][220] = 10  ;

	GFX_CORR[y][221] = 4  ; // book 
	GFX_CORR[x][221] = 26  ;

// dragons

	GFX_CORR[y][222] = 5  ;  
	GFX_CORR[x][222] =  26 ;

	GFX_CORR[y][223] = 6  ;  
	GFX_CORR[x][223] =  26 ;

	GFX_CORR[y][224] = 3  ;  
	GFX_CORR[x][224] =  7 ;

	GFX_CORR[y][225] = 0  ;  
	GFX_CORR[x][225] = 27  ;

	GFX_CORR[y][226] = 1  ;  
	GFX_CORR[x][226] =  27 ;

	GFX_CORR[y][227] = 4  ;  
	GFX_CORR[x][227] = 7  ;

	GFX_CORR[y][228] = 2  ;  
	GFX_CORR[x][228] = 27  ;

	GFX_CORR[y][229] = 3  ;  
	GFX_CORR[x][229] =  27 ;

	GFX_CORR[y][230] = 4  ;  
	GFX_CORR[x][230] =  27 ;

	GFX_CORR[y][231] = 5  ;  
	GFX_CORR[x][231] = 27  ;

	GFX_CORR[y][232] = 6  ;  
	GFX_CORR[x][232] = 27  ;

	GFX_CORR[y][233] = 0  ;  
	GFX_CORR[x][233] = 28  ;

	GFX_CORR[y][234] = 1  ;  
	GFX_CORR[x][234] = 28  ;

	GFX_CORR[y][235] = 2  ;  
	GFX_CORR[x][235] =  28 ;

	GFX_CORR[y][236] = 3  ;  
	GFX_CORR[x][236] = 2  ;

	GFX_CORR[y][237] = 3  ;  
	GFX_CORR[x][237] =  28 ;

	GFX_CORR[y][238] = 4  ;  
	GFX_CORR[x][238] =28   ;

	GFX_CORR[y][239] = 5  ;  
	GFX_CORR[x][239] =  28 ;

	GFX_CORR[y][240] = 6  ; // bolt  
	GFX_CORR[x][240] = 28 ;

	GFX_CORR[y][241] = 2  ; // mushroom  
	GFX_CORR[x][241] = 18 ;

	GFX_CORR[y][242] = 0  ; // teeth...
	GFX_CORR[x][242] = 29 ;

	GFX_CORR[y][243] =  1 ; // coins, PAINTED  like a moneybag.
	GFX_CORR[x][243] = 29 ;

//	GFX_CORR[y][243] =  0 ; // creeping coins, looks like a moneybag.
//	GFX_CORR[x][243] = 13 ;

	GFX_CORR[y][244] =  2 ; // broken bone.
	GFX_CORR[x][244] = 29 ;

	GFX_CORR[y][245] = 2; // edible mold
	GFX_CORR[x][245] = 19;


	GFX_CORR[y][246] = 3; 
	GFX_CORR[x][246] = 29;

	GFX_CORR[y][247] = 4; 
	GFX_CORR[x][247] = 29;

	GFX_CORR[y][248] = 5; 
	GFX_CORR[x][248] = 29;

	GFX_CORR[y][249] = 6; 
	GFX_CORR[x][249] = 29;

	GFX_CORR[y][250] = 5; 
	GFX_CORR[x][250] = 30;

	GFX_CORR[y][251] = 6; 
	GFX_CORR[x][251] = 30;

	GFX_CORR[y][252] = 4; 
	GFX_CORR[x][252] = 30;

	GFX_CORR[y][253] = 3; 
	GFX_CORR[x][253] = 30;

	GFX_CORR[y][254] = 2; 
	GFX_CORR[x][254] = 30;

	GFX_CORR[y][255] = 1; 
	GFX_CORR[x][255] = 30;

	GFX_CORR[y][17] = 0; 
	GFX_CORR[x][17] = 30;

	GFX_CORR[y][1] = 0; 
	GFX_CORR[x][1] = 31;

	GFX_CORR[y][2] = 1; 
	GFX_CORR[x][2] = 31;

	GFX_CORR[y][3] = 2; 
	GFX_CORR[x][3] = 31;

	GFX_CORR[y][4] = 3; 
	GFX_CORR[x][4] = 31;

	GFX_CORR[y][5] = 4; 
	GFX_CORR[x][5] = 31;

	GFX_CORR[y][6] = 5; 
	GFX_CORR[x][6] = 31;

	GFX_CORR[y][7] = 6; 
	GFX_CORR[x][7] = 31;

	GFX_CORR[y][8] = 6; 
	GFX_CORR[x][8] = 32;

	GFX_CORR[y][9] = 5; 
	GFX_CORR[x][9] = 32;

	GFX_CORR[y][10] = 0; 
	GFX_CORR[x][10] = 32;

	GFX_CORR[y][11] = 1; 
	GFX_CORR[x][11] = 32;

	GFX_CORR[y][12] = 0; 
	GFX_CORR[x][12] = 33;

	GFX_CORR[y][13] = 1; 
	GFX_CORR[x][13] = 33;

	GFX_CORR[y][14] = 2; 
	GFX_CORR[x][14] = 32;

	GFX_CORR[y][15] = 3; 
	GFX_CORR[x][15] = 32;

	GFX_CORR[y][16] = 4; 
	GFX_CORR[x][16] = 32;

}
