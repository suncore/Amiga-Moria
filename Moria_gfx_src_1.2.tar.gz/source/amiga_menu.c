// file amigamenu.c
#include <intuition/intuition.h>
#include <intuition/intuitionbase.h>
#include <intuition/screens.h>
#include <exec/types.h>
#include <exec/memory.h>

#define FRONTPEN 0


// **************** texts
static struct IntuiText project_txt [] =
{ {
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Character info         [C,C]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"View scoreboard        [V,V]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Set options            [=,=]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Help                   [?,?]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Previous messages  [C-p,C-p]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Set Automess speed     [g,g]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Automess ON/OFF        [`,`]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Repeat command       [#,num]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"About                  [v,v]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Save & Quit       [C-x, C-x]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Die & Quit           [C-k,Q]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
}
};

static struct IntuiText fight_txt [] = {
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Fire/throw item  [f,t]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Zap wand         [a,z]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Zap staff        [u,Z]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Cast magic spell [m,m]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Pray             [p,p]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Read a scroll    [r,r]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Bash Monster     [B,f]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"(Walk into monster)   ",

  NULL          /* NextItem, no link to other IntuiText static structures. */
}
};

static struct IntuiText info_txt [] = {
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Browse a book     [b,P]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Open door/chest   [o,o]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Search            [s,s]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Search mode       [S,#]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Identify object   [/,/]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Locate with map   [L,W]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Look in direction [l,x]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Show map reduced  [M,M]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Show map 1:4      [,,,]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
}
};





static struct IntuiText action_txt [] = {
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Close door         [c,c]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Jam door           [j,S]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Bash item          [B,f]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Quaff a potion     [q,q]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Eat food           [E,E]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Read scroll        [r,r]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Gain new spell     [G,G]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Zap wand           [a,z]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Zap staff          [u,Z]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Disarm trap, chest [D,D]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Fill lamp with oil [F,F]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Tunnel         [T,C-dir]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Inscribe an object [{,{]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Rest               [R,R]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Restore          [R*,R*]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
}
};


static struct IntuiText inventory_txt [] = {
 {
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"List inventory  [i,i]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"List equipment  [e,e]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Wear/Wield item [w,w]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Drop item       [d,d]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Take off item   [t,T]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Exhange weapons [x,X]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
}
};

static struct IntuiText move_txt [] = {
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Go up staircase      [<,<]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Go down staircase    [>,>]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Move without pickup  [-,-]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Run              [.,S-dir]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Continous run ON/OFF [(,(]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"SouthWest            [1,b]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"South                [2,j]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"SouthEast            [3,n]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"West                 [4,h]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"Stay                 [5,.]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"East                 [6,l]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"NorthWest            [7,y]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"North                [8,k]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
},
{
  FRONTPEN, 0, JAM1, 0, 1, NULL,
"NorthEast            [9,u]",

  NULL          /* NextItem, no link to other IntuiText static structures. */
}
};



static struct MenuItem project11 =  {
	NULL,0,100,228,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&project_txt[10],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem project10 =  {
	&project11,0,90,228,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&project_txt[9],
	NULL,0,NULL,MENUNULL
};


static struct MenuItem project9 =  {
	&project10,0,80,228,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&project_txt[8],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem project8 =  {
	&project9,0,70,228,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&project_txt[7],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem project7 =  {
	&project8,0,60,228,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&project_txt[6],
	NULL,0,NULL,MENUNULL
};


static struct MenuItem project6 =  {
	&project7,0,50,228,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&project_txt[5],
	NULL,0,NULL,MENUNULL
};



static struct MenuItem project5 =  {
	&project6,0,40,228,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&project_txt[4],
	NULL,0,NULL,MENUNULL
};


static struct MenuItem project4 =  {
	&project5,0,30,228,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&project_txt[3],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem project3 =  {
	&project4,0,20,228,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&project_txt[2],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem project2 =  {
	&project3,0,10,228,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&project_txt[1],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem project1 =  {
	&project2,0,0,228,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&project_txt[0],
	NULL,0,NULL,MENUNULL
};



static struct MenuItem info9 =  {
	NULL,0,80,188,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&info_txt[8],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem info8 =  {
	&info9,0,70,188,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&info_txt[7],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem info7 =  {
	&info8,0,60,188,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&info_txt[6],
	NULL,0,NULL,MENUNULL
};


static struct MenuItem info6 =  {
	&info7,0,50,188,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&info_txt[5],
	NULL,0,NULL,MENUNULL
};



static struct MenuItem info5 =  {
	&info6,0,40,188,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&info_txt[4],
	NULL,0,NULL,MENUNULL
};


static struct MenuItem info4 =  {
	&info5,0,30,188,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&info_txt[3],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem info3 =  {
	&info4,0,20,188,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&info_txt[2],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem info2 =  {
	&info3,0,10,188,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&info_txt[1],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem info1 =  {
	&info2,0,0,188,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&info_txt[0],
	NULL,0,NULL,MENUNULL
};


static struct MenuItem fight8 =  {
	NULL,0,70,180,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&fight_txt[7],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem fight7 =  {
	&fight8,0,60,180,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&fight_txt[6],
	NULL,0,NULL,MENUNULL
};
static struct MenuItem fight6 =  {
	&fight7,0,50,180,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&fight_txt[5],
	NULL,0,NULL,MENUNULL
};
static struct MenuItem fight5 =  {
	&fight6,0,40,180,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&fight_txt[4],
	NULL,0,NULL,MENUNULL
};
static struct MenuItem fight4 =  {
	&fight5,0,30,180,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&fight_txt[3],
	NULL,0,NULL,MENUNULL
};
static struct MenuItem fight3 =  {
	&fight4,0,20,180,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&fight_txt[2],
	NULL,0,NULL,MENUNULL
};
static struct MenuItem fight2 =  {
	&fight3,0,10,180,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&fight_txt[1],
	NULL,0,NULL,MENUNULL
};
static struct MenuItem fight1 =  {
	&fight2,0,0,180,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&fight_txt[0],
	NULL,0,NULL,MENUNULL
};


static struct MenuItem action15 =  {
	NULL,0,140,196,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&action_txt[14],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem action14 =  {
	&action15,0,130,196,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&action_txt[13],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem action13 =  {
	&action14,0,120,196,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&action_txt[12],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem action12 =  {
	&action13,0,110,196,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&action_txt[11],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem action11 =  {
	&action12,0,100,196,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&action_txt[10],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem action10 =  {
	&action11,0,90,196,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&action_txt[9],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem action9 =  {
	&action10,0,80,196,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&action_txt[8],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem action8 =  {
	&action9,0,70,196,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&action_txt[7],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem action7 =  {
	&action8,0,60,196,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&action_txt[6],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem action6 =  {
	&action7,0,50,196,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&action_txt[5],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem action5 =  {
	&action6,0,40,196,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&action_txt[4],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem action4 =  {
	&action5,0,30,196,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&action_txt[3],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem action3 =  {
	&action4,0,20,196,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&action_txt[2],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem action2 =  {
	&action3,0,10,196,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&action_txt[1],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem action1 =  {
	&action2,0,0,196,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&action_txt[0],
	NULL,0,NULL,MENUNULL
};


static struct MenuItem inventory6 =  {
	NULL,0,50,174,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&inventory_txt[5],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem inventory5 =  {
	&inventory6,0,40,174,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&inventory_txt[4],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem inventory4 =  {
	&inventory5,0,30,174,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&inventory_txt[3],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem inventory3 =  {
	&inventory4,0,20,174,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&inventory_txt[2],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem inventory2 =  {
	&inventory3,0,10,174,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&inventory_txt[1],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem inventory1 =  {
	&inventory2,0,0,174,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&inventory_txt[0],
	NULL,0,NULL,MENUNULL
};



static struct MenuItem move14 =  {
	NULL,0,130,214,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&move_txt[13],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem move13 =  {
	&move14,0,120,214,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&move_txt[12],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem move12 =  {
	&move13,0,110,214,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&move_txt[11],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem move11 =  {
	&move12,0,100,214,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&move_txt[10],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem move10 =  {
	&move11,0,90,214,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&move_txt[9],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem move9 =  {
	&move10,0,80,214,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&move_txt[8],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem move8 =  {
	&move9,0,70,214,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&move_txt[7],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem move7 =  {
	&move8,0,60,214,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&move_txt[6],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem move6 =  {
	&move7,0,50,214,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&move_txt[5],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem move5 =  {
	&move6,0,40,214,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&move_txt[4],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem move4 =  {
	&move5,0,30,214,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&move_txt[3],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem move3 =  {
	&move4,0,20,214,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&move_txt[2],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem move2 =  {
	&move3,0,10,214,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&move_txt[1],
	NULL,0,NULL,MENUNULL
};

static struct MenuItem move1 =  {
	&move2,0,0,214,10,HIGHCOMP|ITEMENABLED|ITEMTEXT,0,
(APTR)&move_txt[0],
	NULL,0,NULL,MENUNULL
};















static struct Menu move_menu =  {
	NULL,
	412,
	0,
	64,
	0,
	MENUENABLED,
	"Move",
	&move1,
	0,0,0,0
};

static struct Menu inventory_menu =  {
	&move_menu,
	308,
	0,
	104,
	0,
	MENUENABLED,
	"Inv/Equip",
	&inventory1,
	0,0,0,0
};

static struct Menu action_menu =  {
	&inventory_menu,
	228,
	0,
	80,
	0,
	MENUENABLED,
	"Action",
	&action1,
	0,0,0,0
};
static struct Menu info_menu =  {
	&action_menu,
	164,
	0,
	64,
	0,
	MENUENABLED,
	"Info",
	&info1,
	0,0,0,0
};

static struct Menu fight_menu =  {
	&info_menu,
	92,
	0,
	72,
	0,
	MENUENABLED,
	"Fight",
	&fight1,
	0,0,0,0
};

struct Menu project_menu =  {
	&fight_menu,
	4,
	0,
	88,
	0,
	MENUENABLED,
	"Project",
	&project1,
	0,0,0,0
};

